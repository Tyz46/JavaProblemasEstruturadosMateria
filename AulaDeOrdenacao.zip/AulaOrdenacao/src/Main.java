public class Main {
    // Bubble Sort ele compara números vizinhos e troca as posições quando estão fora de ordem
    static void bubblesort(int tamanho, int[] vetor) {
        int temp = 0;
        // i = laço externo, controla qual passagem do algoritmo que estamos executando, andamento geral
        // j = laço interno, controla quais posições do vetor estamos comparando, comparar os números

        // Enquanto (Inicio, Condição, Incremento)

        // Inicia em 0
        // Enquanto i for menor que o tamanho, executa o laço
        // Ao terminar cada laço, aumenta i em 1
        for (int i = 0; i < tamanho; i++) {
            // Inicia em 1
            // Enquanto o j for menor que o tamanho menos o i, executa o laço
            // Ao terminar cada laço, aumenta j em 1
            for (int j = 1; j < tamanho - i; j++) {
                // Se o número da esquerda for maior que o número da direita, então...
                if (vetor[j - 1] > vetor[j]) {
                    // Guardando o número em uma váriavel temporária
                    temp = vetor[j - 1];
                    // Alterando o número esquerdo para o número da direita
                    vetor[j - 1] = vetor[j];
                    // Troca o número da direita para o valor temporário guardado
                    vetor[j] = temp;
                }
            }
        }
    }

    // Insertion Sort pega o elemento e procura direto a posição dele dentro de um vetor ja ordenado
    public void insercaoDireta(int[] vetor, int tamanho) {
        int chave, j;

        for (int i = 1; i < tamanho; i++) {
            chave = vetor[i];
            j = i - 1;
            while (j >= 0 && vetor[j] > chave) {
                vetor[j + 1] = vetor[j];
                j = j - 1;
            }
            vetor[j + 1] = chave;
        }
    }

    int separar(int[] vetor, int inicio, int fim) {
        int pivo = vetor[inicio];
        int  i = inicio + 1;
        int f = fim;

        while  (i <= f) {
            while (i <= fim && vetor[i] <= pivo) {
                i += 1;
            }
            while (f > inicio && vetor[f] > pivo) {
                f -= 1;
            }
            if (i < f) {
                int troca = vetor[1];
                vetor[i] = vetor[f];
                vetor[f] = troca;
                i += 1;
                f -= 1;
            }
        }
        vetor[inicio] = vetor[f];
        vetor[f] = pivo;
        return f;
    }

    public void quicksort (int[] vetor, int inicio, int fim) {
        if (inicio < fim) {
            int posicaoPivo = separar(vetor, inicio, fim);
            quicksort(vetor, inicio, posicaoPivo - 1);
            quicksort(vetor, posicaoPivo + 1, fim);
        }
    }

    public static void main(String[] args) {

    }
}